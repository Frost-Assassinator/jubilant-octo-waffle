Page({
  data: {
    timeToday:0,  //本次学习时间
    timeCountDown:0,  //输入的时间
    b:false,  //配合wx：if用于判定语句是否显示
    b0:false,
    timeDisplay: 0  //存储上一次计时的时间
  },

  onLoad: function (options) {
    var that = this
    wx.cloud.callFunction({ //调用云函数读取上一次学习时间
      name:"readTime",
      success:function(res){
        that.setData({
          timeToday:res.result.data[res.result.data.length - 1].time  //用timeToday接收
        })
      }
    })
  },

  countTime: function(e){
    //console.log(e);
    this.setData({
      timeCountDown: e.detail.value //接收输入的数值
    })
  },

  startCount: function(){
    this.setData({
      b0: true, //点击开始计时后显示计时开始
      b: false  //令上一次计时结果不可见
    })
    var studyTime = this.data.timeCountDown
    var that = this
    setTimeout(function(){  //setTimeout API，在倒计时结束后调用预先设定好的函数
      that.setData({
        b: true,  //显示计时结束及计时结果
        b0: false,  //令计时开始不可见
        timeDisplay: studyTime  //存储计时时间，否则会在输入下一次时间时计时结果也会跟随输入内容一起变化
      }),
      wx.cloud.database().collection("timeRecord").add({  //上传计时数据到云数据库
        data:{
          time:studyTime * 1  //乘1为了防止数据上传至云数据库后变为string类型，在进行假发运算时变为字符串直接相加
        },
        success: function(res){}
      })
    },studyTime*1e3,null) //微信默认时间单位为毫秒，乘六万变为分钟，为了方便调试设定为秒
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {  //下拉刷新触发事件，与onLoad相同
    this.setData({
      b: false
    })
    var that = this
    wx.cloud.callFunction({
      name:"readTime",
      success:function(res){
        that.setData({
          timeToday:res.result.data[res.result.data.length - 1].time
        })
      }
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})