Page({
  data:{
    timeToday:0,
    timeRecent:0,
    days: 0
  },

  onLoad(){
    var that = this
    wx.cloud.callFunction({
      name:"readTime",
      success:function(res){
        //console.log(res)
        
        var k=1

        that.setData({
          timeToday:res.result.data[res.result.data.length-1].time
        })

        if(res.result.data.length<3){
          that.setData({
            timeRecent:"Null"
          })
        }
        else{
          for(k;k<=3;k=k+1)
        {
          that.setData({
            timeRecent:that.data.timeRecent+res.result.data[res.result.data.length-k].time
          })
        }
        }
      }
    })

    wx.cloud.callFunction({
      name:"getDays",
      success: function(res){
        var result = res.result.data
        that.setData({
          days: result[result.length - 1].days
        })
      }
    })
  },

  onPullDownRefresh: function () {
    this.setData({
      timeToday: 0,
      timeRecent: 0
    })
    var that = this
    wx.cloud.callFunction({
      name:"readTime",
      success:function(res){
        //console.log(res)
        
        var k=1

        that.setData({
          timeToday:res.result.data[res.result.data.length-1].time
        })

        if(res.result.data.length<3){
          that.setData({
            timeRecent:"Null"
          })
        }
        else{
          for(k;k<=3;k=k+1)
        {
          that.setData({
            timeRecent:that.data.timeRecent+res.result.data[res.result.data.length-k].time
          })
        }
        }
      }
    })

    wx.cloud.callFunction({
      name:"getDays",
      success: function(res){
        var result = res.result.data
        that.setData({
          days: result[result.length - 1].days
        })
      }
    })
  }
})