Page({
  data: {
    days: 0,  //接收之前的打卡天数数据，用于显示打卡天数
    addDays: 0  //接收之前的天数数据，用于上传新的数据
  },

  onLoad: function(options){  //初始化事件函数
    var that = this
    wx.cloud.callFunction({ //调用云函数读取之前打卡的总天数
      name: "getDays",
      success: function(res){
        //console.log(res)
        var result = res.result.data
        if(result.length != 0){ //若有数据存在，则将最后一次打卡记录的天数赋值给days变量；若无数据，则仍为初始值0
          that.setData({
            days: result[result.length - 1].days
          })
        }
      }
    })
  },

  upload: function(){ //点击打卡触发该函数
    
    var that = this;
    wx.cloud.callFunction({ //调用云函数读取云数据库中的数据
      name:"getDays",
      success:function(res){
        var result = res.result.data[res.result.data.length -1].days
        console.log(result)
        that.setData({
          days : result+1 //更新显示的数据
        })
        var days=result;
        var db = wx.cloud.database()
        db.collection("days").add({ //向云数据库添加一条数据，用来记录本次打卡信息
        data:{
        days:days+1 //天数为上一次打卡时记录的天数加1
        },
        success:function(res){
        console.log(res)
        }
        })
  
  }
  })
  
 
 
},

  onPullDownRefresh: function(){  //下拉刷新触发事件，与onLoad函数相同
    var that = this
    wx.cloud.callFunction({
      name: "getDays",
      success: function(res){
        //console.log(res)
        var result = res.result.data
        if(result.length != 0){
          that.setData({
            days: result[result.length - 1].days
          })
        }
      }
    })
  }
  })